# COMP3120 Assignment 2 - Unit Reviewer - Group AE

## Deploy

The official heroku url for the project is https://unit-reviewer.herokuapp.com/

## CI

If you open a pull request Heroku will build a review app for you to preview the changes

## API

API docs are available at /api-docs or https://unit-reviewer.herokuapp.com/api-docs
