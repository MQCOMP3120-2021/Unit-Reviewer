export const JWT_SECRET = 'LKi@qcdmfHjkFoNdrv3Pa$H^dWCG6$8*7wm^!gU$Yt5U';
export const JWT_COOKIE_NAME = 'auth';
export const SALT_ROUNDS = 12;
